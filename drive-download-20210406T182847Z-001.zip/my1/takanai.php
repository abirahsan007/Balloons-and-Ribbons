<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>taka nai</title>
    <style>
        .des {
            text-align: center;
            display: inline-block;
            font-size: 97px;
            color: red;
            font-style: oblique;
        }
        .alert {
            padding: 20px;
            background-color: #f44336;
            color: white;
            }

            .closebtn {
            margin-left: 15px;
            color: white;
            font-weight: bold;
            float: right;
            font-size: 22px;
            line-height: 20px;
            cursor: pointer;
            transition: 0.3s;
            }

            .closebtn:hover {
            color: black;
            }

    </style>
</head>
<body>
    <h1 class="des"> <a class="des" href="customerpage.php">Pocket khali apnar.Bank balance check koren please....thank you</a> </h1>
</body>
</html>