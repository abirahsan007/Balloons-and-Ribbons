<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pending</title>
    <style>
        .des {
            text-align: center;
            display: inline-block;
            font-size: 97px;
            color: red;
            font-style: oblique;
        }

    </style>
</head>
<body>
    <h1 class="des"> <a class="des" href="customerpage.php">Request Pending For this Venue</a> </h1>
</body>
</html>